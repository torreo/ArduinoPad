/** Automatically generated file. DO NOT MODIFY */
package com.note4me.arduinopad;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}